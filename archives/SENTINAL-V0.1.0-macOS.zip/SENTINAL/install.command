#!/bin/zsh
set -eu
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"
export YOLO_CONFIG_DIR="$PROJECT_DIR/config/runtime/ultralytics"
export MPLCONFIGDIR="$PROJECT_DIR/config/runtime/matplotlib"
export YOLO_AUTOINSTALL=false
mkdir -p "$YOLO_CONFIG_DIR" "$MPLCONFIGDIR"
if [[ ! -x .venv/bin/python ]]; then
  PYTHON_BIN=""
  for candidate in /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 python3.12 python3.11; do
    if command -v "$candidate" >/dev/null 2>&1; then PYTHON_BIN="$candidate"; break; fi
  done
  if [[ -z "$PYTHON_BIN" ]]; then
    print "Install Python 3.12 from python.org or Homebrew, then run this file again."
    read -r "?Press Return to close. "
    exit 1
  fi
  "$PYTHON_BIN" -m venv .venv
fi
.venv/bin/python -m pip install --disable-pip-version-check --no-cache-dir -r requirements-lock.txt
.venv/bin/python tools/download_model.py
.venv/bin/python -m pip check
print "SENTINAL is installed. Open launch.command to begin."
read -r "?Press Return to close. "
