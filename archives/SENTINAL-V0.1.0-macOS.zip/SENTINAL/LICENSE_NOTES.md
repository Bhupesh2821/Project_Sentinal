# Licensing and third-party notices

SENTINAL source is provided under AGPL-3.0, in alignment with its Ultralytics integration. See LICENSE. This is a development source distribution; dependencies retain their own licenses and notices.

- Ultralytics 8.4.183 and YOLO11n COCO weights: AGPL-3.0 / separate Ultralytics Enterprise terms. This deliverable uses the open-source route, with full source supplied. [Official license](https://github.com/ultralytics/ultralytics/blob/main/LICENSE), [model documentation](https://docs.ultralytics.com/models/yolo11/).
- ByteTrack original algorithm/repository: MIT. The implementation used here is the one distributed within Ultralytics under its package terms. [Original ByteTrack](https://github.com/FoundationVision/ByteTrack).
- PyTorch/torchvision: BSD-style licenses. [PyTorch license](https://github.com/pytorch/pytorch/blob/main/LICENSE).
- OpenCV: Apache-2.0 for current OpenCV; opencv-python packaging MIT plus bundled binary third-party notices. [Package](https://pypi.org/project/opencv-python/).
- PySide6/Qt for Python: LGPLv3/GPLv3 or commercial terms; dynamically installed official wheels. [Qt licensing](https://doc.qt.io/qtforpython-6/licenses.html).
- NumPy BSD, SciPy BSD, Pillow MIT-CMU, pytest MIT, lap BSD-2-Clause, and other transitive dependency licenses remain with their authors. Exact installed versions are recorded in requirements-lock.txt.

Public test asset provenance is recorded in docs/FIXTURES.md. Images are not claimed as SENTINAL intellectual property. Model weights are pinned by SHA256 in models/yolo11n.sha256; this pin records the actual downloaded official asset, not an independent signature.
