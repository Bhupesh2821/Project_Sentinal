# SENTINAL — MARK-007
## V0.1.0 · VISION CORE

Local macOS desktop vision prototype. Detects COCO objects with YOLO11n and associates consecutive detections with ByteTrack. The interface shows the original video, bounding boxes, category, confidence and available track IDs. There is no facial recognition, identity lookup, threat scoring or unattended-baggage alerting in V0.1.

### Start on this Mac

Open **launch.command** in Finder. The environment and model in this working folder have already been installed. Select a camera or choose **Open video**, then press **Start monitoring**. Camera access is never started automatically. Press **Stop** to release the source. At the end of a file, **Replay video** opens a fresh session with reset tracking state. You can select another source after stopping.

### Install from a fresh copy or ZIP

1. Install Python **3.12** for Apple Silicon (Python 3.11 is an unverified alternative; 3.14 is not the tested environment).
2. Extract the project to a writable local folder. Open **install.command** once. Internet is needed to install packages and, if absent, download the official model. There are no API keys, paid services or accounts.
3. Open **launch.command**. If macOS does not allow a script to open directly, open Terminal in the project folder and run `zsh install.command`, then `zsh launch.command`.

The scripts quote their project path and work with spaces. They do not require separate backend services. The ZIP excludes the machine-specific Python environment; installation creates a fresh one. Wheels are pinned in `requirements-lock.txt`. PyTorch/PySide6 wheels in this verified stack require macOS 14 or later.

### Monitoring controls

- **Camera** lists devices passively through Qt. OpenCV camera indices are mapped by enumeration order on a best-effort basis; test your selected external camera. The built-in/default camera is preferred where identifiable.
- **Open video** accepts local files only. OpenCV determines codec support. MP4/H.264 and AVI/MJPEG are typical options; a damaged or unsupported file produces a readable error.
- **Boxes**, **Labels**, and **Track IDs** control overlays independently. Coordinates remain in original source pixels while the view scales with its aspect ratio preserved.
- **Confidence** filters the displayed detections after ByteTrack receives lower-confidence candidates. Raising it reduces displayed objects. The filter can show all 80 COCO classes or just people and supported bags.
- **Metadata recording** is OFF at every application launch. Enable it to save sampled detection metadata locally. No video or audio is recorded.
- The **FPS** statistic measures capture + detection + tracking processing throughput; it excludes UI paint time and file playback pacing. File playback is capped at its source rate and slows when inference cannot keep up. **Vision latency** includes preprocessing, inference, model postprocessing and tracking, with MPS synchronization. It is an elapsed measurement, not GPU utilization.

### Configuration and model

Edit `config/settings.json` while monitoring is stopped, then relaunch. Invalid settings produce a configuration error. Default capture is 640 × 480, inference size 640, confidence .25, device `auto`. Valid inference sizes: 320, 480, 640, 960. Use `main.py --device cpu` to force CPU, or `--video /absolute/path/movie.mp4` to preselect a video; Start is still required.

YOLO11n (`models/yolo11n.pt`) is a 2.6-million-parameter COCO pretrained detection model. Required labels in the loaded model are checked at runtime: person (0), backpack (24), handbag (26), suitcase (28). The model exposes 80 classes, listed in `docs/MODEL_CLASSES.json`. A supported class does not imply reliable detection in every view. There is no specialized firearm detector. Ultralytics provides NMS through its supported tracking interface (`iou=.7`), and ByteTrack runs with persistent state only within one source session.

Weights load once per application worker; changing source resets tracking without reloading weights. `auto` prefers MPS when available. An MPS operation failure retries using the same model weights on CPU, rebuilds backend state and offsets restarted IDs within that session. A session UUID combined with a track ID is the persistent identity key. IDs are estimates and can change after misses, occlusion or scene changes.

### Privacy, storage and retention

Processing is local. Monitoring accepts camera indices and existing local paths, not stream URLs. Runtime Ultralytics offline mode and automatic-install disablement are set before library import; telemetry sync is disabled. Only `install.command`/`tools/download_model.py` intentionally downloads model or dependency files. Camera frames are not uploaded. There is no microphone capture.

When explicitly enabled, `recordings/detections.sqlite3` contains UTC timestamps, source filename/camera number, session UUID, frame/time index, category, confidence, optional track ID, source-coordinate boxes, processing FPS, latency and backend. A snapshot is sampled at most once every two wall-clock seconds by default. SQLite writes are atomic. A write failure disables recording and leaves vision running. Empty snapshots do not create detection rows. Retention pruning runs on database open and sampled writes: seven days and 100,000 newest detection rows by default. No background cleanup runs while the app is closed. SQLite may retain freed disk pages; this is a bounded development store, not secure erasure. With monitoring closed, delete the database and its `-wal`/`-shm` files to remove saved metadata. Local diagnostic logs rotate at 2 MB with three backups. They contain errors, potentially filenames, and no frames/audio.

### Architecture

`sentinal/vision` provides validated data contracts, source lifecycle, detector/tracker, performance and `VisionPipeline`. It is reusable without Qt or SQLite. `core/device_manager.py` selects/synchronizes inference backends. `core/event_manager.py` samples optional metadata into `storage/database.py`. `interface` renders the dashboard. A persistent QThread owns pipeline and database operations. A single latest-frame mailbox prevents video signals accumulating in the GUI queue; the GUI polls it on a timer. Stop and shutdown are cooperative and release resources in `finally`. There is no forced thread termination.

Heavy vision-library imports occur before the window is shown; a cold launch may take several seconds. Model weights still load only in the worker on Start. The vision loop has bounded rolling metrics and no recording buffer. File frames are processed sequentially. Camera buffer size is requested as 1, although AVFoundation may ignore this property. There is no claim of guaranteed capture latency or cross-process camera exclusivity; SENTINAL prevents competing capture objects inside its own process.

See `docs/FUTURE_UPGRADES.md` for the exact V0.2 integration boundary.

### Tests and verification

Read **VERIFICATION_REPORT.md** for measured results and remaining acceptance work. Automated unit/mock tests cannot establish hardware or model accuracy.

From the project folder:

```sh
.venv/bin/python -m pytest -q
SENTINAL_TEST_VIDEO="$PWD/tests/fixtures/vtest.avi" .venv/bin/python -m pytest tests/test_real_pipeline.py -q
.venv/bin/python tools/verify_pipeline.py --help
.venv/bin/python tools/verify_desktop.py --help
```

The public real fixtures and evidence are described in `docs/FIXTURES.md`. Synthetic codec fixtures in pytest test lifecycle only. Benchmark JSON is in `docs/evidence`; native dashboard screenshots are in `docs/verification-native`. The verification report distinguishes earlier restricted-context failures from later successful native tests.

### Troubleshooting and limitations

Camera permission: open System Settings → Privacy & Security → Camera and allow the launcher/Terminal/Python host that macOS names, then close and relaunch. A Python/Terminal launch can have a different permission identity from a packaged app. If no camera is enumerated, connect one, refresh the list, and check permissions. Close other apps using the camera. A denied/disconnected device displays an error; no substitute stream is generated.

A missing model produces an installation instruction without an automatic runtime download. Run `install.command` to restore it. If MPS is unstable, launch with `zsh launch.command --device cpu`. If playback is slow, reduce inference size in settings to 480 or 320; small/distant bags can become harder to detect. For unsupported codecs, transcode your own file to a supported format. A file whose decoder provides no reliable frame count may have an ambiguous truncation vs EOF; this decoder limitation is documented rather than concealed.

Tracking is not re-identification. Long occlusions, overlap, similar objects, rapid movement, camera motion and low-confidence detections can break identities. The tracker buffer is frame based; duration varies with processed frame rate. No calibrated accuracy, public-safety efficacy, multi-camera identity, unattended-bag reasoning or alert system has been established. A signed standalone `.app` is a future packaging task.
