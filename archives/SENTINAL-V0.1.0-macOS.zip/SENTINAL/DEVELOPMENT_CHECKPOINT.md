# SENTINAL development checkpoint

The source implementation is in this folder. Preserve it; do not rebuild from scratch.

The 2026-10-20 development run was interrupted by the account usage limit after source creation and dependency downloads. Development resumed on 2026-10-21. Dependencies now installed in .venv; requirements-lock.txt records the actual environment. Unused PySide6 WebEngine/PDF bundles were removed; native Essentials/Addons remain.

The authoritative final status belongs in VERIFICATION_REPORT.md and raw JSON/screenshots under docs/evidence. Never mark a capability verified merely from source or mock tests. Downloaded public real fixtures are listed in docs/FIXTURES.md. Camera footage is not stored by default.

Core boundaries: VisionPipeline -> FramePacket, persistent InferenceWorker with one-frame mailbox -> MainWindow; optional EventManager -> DetectionDatabase. Tests, GUI verification and offline verification must be rerun after relevant source changes. No advanced BAGWATCH logic has been implemented.

Final validation on 2026-10-21: 136 pytest tests passed including real video; native Cocoa desktop 34 checks passed; actual built-in camera UI 83 checks passed across five sessions; CPU/MPS benchmark complete. Final report lists remaining moving-bag/field and long-run coverage. Source implementation is finished for demonstrated paths.
