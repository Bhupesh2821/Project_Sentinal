"""Installation-time failures do not leave partial model files or use runtime inference."""
import importlib.util
from pathlib import Path
import pytest


def load_downloader():
    path=Path(__file__).resolve().parents[1]/'tools/download_model.py'
    spec=importlib.util.spec_from_file_location('sentinal_test_downloader',path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_download_failure_removes_partial_and_explains_retry(tmp_path,monkeypatch,capsys):
    module=load_downloader()
    monkeypatch.setattr(module,'ROOT',tmp_path)
    def unavailable(*args,**kwargs):
        raise OSError('offline test')
    monkeypatch.setattr(module,'urlopen',unavailable)
    with pytest.raises(SystemExit) as error:
        module.main()
    assert error.value.code==1
    assert not (tmp_path/'models/yolo11n.part').exists()
    assert not (tmp_path/'models/yolo11n.pt').exists()
    assert 'retry install.command' in capsys.readouterr().err


def test_unexpected_model_bytes_fail_checksum_before_publish(tmp_path,monkeypatch):
    from io import BytesIO
    module=load_downloader()
    monkeypatch.setattr(module,'ROOT',tmp_path)
    (tmp_path/'models').mkdir()
    (tmp_path/'models/yolo11n.sha256').write_text('0'*64+'  yolo11n.pt\n')
    monkeypatch.setattr(module,'urlopen',lambda *args,**kwargs:BytesIO(b'not the official model'))
    with pytest.raises(SystemExit):
        module.main()
    assert not (tmp_path/'models/yolo11n.pt').exists()
    assert not (tmp_path/'models/yolo11n.part').exists()
