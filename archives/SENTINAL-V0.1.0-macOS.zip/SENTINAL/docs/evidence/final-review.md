# Independent delivery review — 2026-10-21

Reviewed the actual configuration, source/camera lifecycle, detector, Ultralytics tracking adapter, pipeline, worker, Qt controls/rendering, event/storage implementation, install/launch scripts, tests and documentation. This review did not run model inference or activate a camera.

## Functional findings

- **Configuration defect found and corrected:** `AppConfig(max_detection_rows=100.5)` was accepted, but `DetectionDatabase(..., max_rows=100.5)` raised `sqlite3.IntegrityError: datatype mismatch` during pruning because SQLite `OFFSET` requires an integer. This was reproduced directly using a temporary database. The correction validates integer dimensions/size/retention/row cap, rejects booleans/strings as numeric settings, validates finite confidence/sampling values, and reports invalid path/device types as early `ValueError`. Regression coverage includes the fractional row cap and a valid SQLite configuration. The default settings remain valid.
- All visible controls have connected implementations: source selection/refresh, file loading, start/stop/replay, class filter, confidence, independent overlays and opt-in metadata. No placeholder detections or advanced incident buttons were found.
- The model receives `conf=0.05`, NMS `iou=0.7`, and persistent ByteTrack within a source session; the user confidence filter is applied afterward. The installed ByteTrack configuration itself uses high/new-track thresholds of 0.25 and a low-track threshold of 0.1, so lowering the presentation slider does not independently change new-track creation thresholds.
- Source coordinates are clipped/validated once, then scaled for the aspect-preserving video view. Session UUIDs separate persistent track identities. MPS retry rebuilds the predictor and offsets restarted IDs. Source and database cleanup paths are implemented; camera blocking behavior still depends on the native backend returning from capture calls.
- SQLite is opt-in and stores metadata only. The stated default sampling interval, seven-day retention, 100,000-row cap, pruning cadence and no-secure-erasure qualification agree with the implementation. Vision continues after a recording failure.

## Checks performed

Before the fix, `python -m pytest tests/test_config_types.py tests/test_storage_events.py -q`: **39 passed in 0.11 s**. After the fix and new regressions: **81 passed in 0.15 s**. These tests cover contracts/storage and are not model/camera proof. The original fractional row-limit reproduction deliberately failed and used a temporary database only; the added regression verifies that configuration now rejects it before database initialization.

Existing evidence was inspected rather than regenerated: the earlier full pytest evidence reports 92 passed (a final full-suite rerun is required after the added tests), native desktop evidence identifies Cocoa/MPS with no failures, offline evidence records no Python socket attempts, and the native camera evidence records a real 640×480 frame with capture released. Parent development is extending on-device acceptance and refreshing final report/benchmarks; earlier restricted-context failures must not be mistaken for current native blockers.

## Delivery checks to finish

- Update benchmark/backend text and screenshot paths to the final evidence locations. Earlier CPU-only/MPS-unavailable text is superseded where the later native results demonstrate MPS.
- Keep moving-bag tracking, camera disconnection/permission denial, or other field behavior marked unverified unless suitable real evidence has since been added. Still-image bag detections cannot establish moving-bag identity continuity.
- Inspect the final archive member list: exclude `.venv`, caches, `config/runtime`, logs, detection databases and `-wal`/`-shm` files. No final ZIP existed at this review point. Install and launch scripts are executable and quote their project paths.

No other release-blocking source flaw was identified by this inspection. This is a bounded review, not a claim of full accuracy, hardware reliability or exhaustive absence of defects.
