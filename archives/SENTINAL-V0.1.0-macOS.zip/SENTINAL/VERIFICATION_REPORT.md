# SENTINAL V0.1.0 — Verification report

**Date:** 2026-10-21. **Status:** working macOS Vision Core delivered with real camera, native desktop, CPU/MPS inference and local metadata verified. Full field acceptance is still pending moving-bag identity tests, physical external-camera disconnection and extended operation. No claim of surveillance accuracy or autonomous incident interpretation is made.

## Environment and actual execution

Apple M4 MacBook Air, 16 GB RAM, macOS 26.6.2 arm64; Python 3.12.15; Ultralytics 8.4.183; PyTorch 2.14.1; torchvision 0.29.1; OpenCV 4.14.0; Qt/PySide6 Essentials/Addons 6.12.0; lap 0.5.13. Dependencies were installed in a clean local environment. `requirements-lock.txt` captures the installed dependency versions; `pip check` passed. Unused Qt WebEngine/PDF bundles were removed.

The initial restricted execution context could not connect to macOS desktop services, denied camera access, and reported MPS unavailable. Those attempts remain as clearly named historical evidence. Later approved native execution outside that restricted context successfully displayed Cocoa windows, used MPS and opened the built-in camera. **The earlier restrictions are not current native-device blockers.**

The model is official local `yolo11n.pt`, SHA256 `0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1`. Its 80 COCO classes include person, backpack, handbag and suitcase. Model/dependency installation is the only intentional download stage. License and class details are in LICENSE_NOTES.md and docs/MODEL_CLASSES.json.

## Tests executed and results

| Test | Result | Evidence / scope |
|---|---|---|
| Full pytest suite, including opt-in real-video test | **136 passed; 0 failed; 0 skipped**, 11.41 s | `docs/evidence/pytest.txt`. Most are deterministic unit/component tests; one uses actual weights and 30 recorded moving-video frames. |
| Native desktop with actual YOLO/ByteTrack video pipeline | **34 checks passed**, Cocoa, MPS | `docs/verification-native/desktop-verification.json`; real screenshots alongside. |
| Native camera dashboard | **83 checks passed**, five real camera sessions | `docs/evidence/camera-desktop.json`; six distinct displayed camera frames per cycle; no camera media saved. |
| Direct built-in camera capture | **Passed**, 640 × 480 BGR frame, source reported 24 FPS | `docs/evidence/camera-native.json`; capture released. Reported capture rate is not measured inference throughput. |
| Native CPU and MPS resolution comparison | **All six video runs passed**, 90 real frames per run | `docs/evidence/native/benchmark-native.json`; no benchmark run failures. |
| Real static bag examples, CPU/MPS | Actual bag outputs demonstrated; misses retained | `docs/evidence/native/bag-*.json`, original annotations and rendered results. |
| Offline real model inference | **Passed**, zero attempted Python DNS/socket operations | `docs/evidence/offline.json`; audited Python networking denied before imports, offline flag false-for-online, sync disabled. This is not an OS-wide packet capture. |
| Installation/launcher | **Passed** dependency consistency, local model checksum and launch help; scripts tested through a project path containing spaces | `docs/evidence/installation-check.txt`; script syntax checked. ZIP creates a fresh environment through installer. |
| Independent code review | Configuration defect found, fixed and regression tested | `docs/evidence/final-review.md`. Fractional SQLite row limits and other malformed settings now fail early. |

Native desktop checks exercised real video opening, people detections, assigned IDs, measured metrics, confidence and focus filtering, every overlay toggle, opt-in SQLite recording, stop, restart/model reuse, independent source switch, EOF/replay, missing-file error/recovery and clean thread shutdown. Camera checks exercised actual Start/Stop controls five times, unique session UUIDs, persistent model reuse, rendering, UI timer activity, capture release and worker shutdown. Camera metadata logging stayed disabled and the existing database was unchanged. No camera snapshots, boxes or per-object IDs were saved by that camera verifier.

Unit/component tests cover settings, box validation, model result conversion, absent IDs, empty detections, counts, source lifecycle, real decoder failure paths, simulated camera loss/exclusivity, backend selection and simulated MPS failure/CPU retry, missing/unsupported weights, metadata formatting, database persistence/rollback/pruning, sampling and write failures, desktop rendering/controls, download failure and checksum rejection. Such tests are not evidence of real disconnected hardware, model accuracy or actual MPS operation failures.

## Measured performance

Real OpenCV pedestrian video, 768 × 576, 90 processed frames per device/size. Values below exclude first-frame initialization; source decoding, detection and tracking are included in processing FPS. GUI paint and the desktop's deliberate 10 FPS file playback pacing are excluded.

| Inference size | CPU processing FPS | CPU mean vision latency | MPS processing FPS | MPS mean vision latency |
|---|---:|---:|---:|---:|
| 320 | 34.58 | 27.76 ms | 55.15 | 17.13 ms |
| 480 | 22.05 | 44.27 ms | 46.80 | 20.31 ms |
| 640 | 13.45 | 73.23 ms | 37.15 | 25.71 ms |

These are observed processing capacities on one short public video, not fixed live-camera promises. During five brief camera control cycles at 640 inference / 640 × 480 capture, warmed cycles measured **7.36–13.00 processing FPS** and **51.51–100.89 ms** rolling vision latency; camera read overhead and a changing live scene differ from the recorded-video benchmark. Each cycle sampled only six displayed frames, so these are short acceptance measurements rather than a sustained thermal benchmark. The first cold camera cycle included initialization and had 623.29 ms rolling latency. Normal measured stop times were 68–105 ms.

The native video UI timer's p95 same-stage gap was 11.98 ms; its largest same-stage gap was 123.57 ms, including startup. The largest gap during first video loading/inference was 83.31 ms. The camera verifier recorded 1,133 timer callbacks with maximum same-stage gap 54.91 ms. This supports responsiveness in these runs, not a guarantee against all OS/driver stalls. Heavy Python library imports are deliberately performed before showing the window. The recorded native pre-window startup was 13.06 s, including 3.79 s of vision-library preparation. Initial cold MPS inference emitted an Ultralytics NMS time-limit advisory; the run completed with detections and no verification failure. Cold startup can be slow.

## Detection and tracking limits observed

The original three COCO128 development images were tested at 320/480/640 using class-matched IoU ≥ 0.5 against their supplied annotations:

| Image/category | 320 matches | 480 matches | 640 matches |
|---|---:|---:|---:|
| 260 / suitcase | 1 of 3 | 1 of 3 | 3 of 3 |
| 328 / backpack | 0 of 2 | 1 of 2 | 1 of 2 |
| 315 / handbag | 0 of 3 | 0 of 3 | 0 of 3 |

Suitcase image 260 also produced two unmatched suitcase boxes at 640. Original missed handbags remain in the report. Additional deliberately selected real photos demonstrated a backpack (image 257), suitcase (572), and handbag (532); the handbag box in image 532 matches an annotated handbag at approximately 0.949 IoU. Image 536 produced a handbag label but its box was just below the 0.5 matching cutoff; it is retained as an imperfect localization example. These selected examples demonstrate supported output paths, not calibrated accuracy. COCO128 comes from train2017 and may overlap model pretraining data.

Real moving pedestrian footage produced multiple simultaneous IDs and repeated IDs across frames. At size 640 in the original 60-frame CPU run, person ID 4 was absent between frames 17 and 35, and ID 15 had gaps of 6, 13 and 1 observations. These are visible detection/track interruptions. Without identity ground truth they cannot be counted as confirmed ID switches. Perfect tracking, long-occlusion recovery, cross-camera identity and moving-bag identity continuity have not been established.

## Acceptance checklist

| Requirement | Evaluation |
|---|---|
| Python application / dark interface / actual source open | **PASS** native Cocoa desktop and real camera/video. |
| Real model loads / person detection | **PASS** actual model outputs on real recorded footage. Camera counts are unannotated model observations, not verified physical-person counts. |
| Supported bag detection | **PASS for real static examples; PARTIAL for field footage.** All target classes emitted; scene-dependent misses documented. Moving-bag field tests remain pending suitable footage. |
| Boxes / confidence / IDs | **PASS** native screenshots, coordinate render checks and actual tracking packets. |
| Tracking across moving frames | **PASS for ordinary pedestrian association.** Multiple moving bags and long occlusion remain unverified. |
| Start/Stop / safe release / repeated operation | **PASS** five real camera cycles plus native file lifecycle tests. |
| FPS / latency | **PASS** measured values above; no fabricated GPU utilization. |
| CPU/MPS / fallback | **PASS** real CPU and MPS runs; real restricted-context CPU selection; runtime-operation failure retry tested with controlled failures. |
| Unavailable/denied camera | **PASS for actual restricted-context denial and cleanup.** Physical external-camera unplug remains unverified. |
| Optional metadata | **PASS** real video GUI opt-in persistence plus unit tests; off by default. |
| Shutdown/resources | **PASS for normal native close and worker shutdown.** Forced OS termination and long soak not exercised. |
| Automated tests / end-to-end inference | **PASS**, 136 tests plus native integration evidence. |
| Startup / architecture / future module documentation | **PASS**, README and docs/FUTURE_UPGRADES.md. |

## Outstanding work and exact follow-up

No known implementation defect remains that prevents the demonstrated V0.1 paths. Remaining acceptance gaps are: suitable moving footage with independently checked backpack/handbag/suitcase identities, multiple bags with occlusion, physical external-camera disconnect/switch tests, and extended memory/thermal runs. Follow `docs/ON_DEVICE_ACCEPTANCE.md` and record misses and ID swaps rather than assuming success. A second camera was enumerated but not selected or verified. Signing/notarization and a standalone `.app` are outside V0.1 scope.

The application implements no bag ownership, abandonment, criminal intent, identity recognition, facial recognition or high-priority alert logic. Future BAGWATCH integration is documented without presenting those features as implemented.
