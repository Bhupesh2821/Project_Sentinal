"""SENTINAL MARK-007 Vision Core."""
import os
from pathlib import Path

# Set before importing Ultralytics. Downloads belong to install.command only.
_runtime = Path(__file__).resolve().parents[1] / "config/runtime"
os.environ["YOLO_OFFLINE"] = "true"
os.environ["YOLO_AUTOINSTALL"] = "false"
os.environ["YOLO_CONFIG_DIR"] = str(_runtime / "ultralytics")
os.environ["MPLCONFIGDIR"] = str(_runtime / "matplotlib")
__version__ = "0.1.0"
