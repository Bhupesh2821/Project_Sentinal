"""Desktop entry point; importing the vision core does not require Qt."""
import argparse
from dataclasses import replace
import logging
import signal
import sys
from time import perf_counter

from sentinal.config import load_config


def prepare_runtime():
    """Import vision libraries before a window is visible.

    Python's first heavyweight imports can hold the interpreter lock even from
    a QThread. Moving them to application startup keeps that cold import pause
    out of monitoring interactions. This does not load weights, infer, open a
    camera, or start a monitoring session.
    """
    started = perf_counter()
    import ultralytics
    from ultralytics import YOLO  # loads the lazy model-family Python modules
    from ultralytics.trackers import register_tracker
    import torchvision
    details = {
        "elapsed_s": perf_counter() - started,
        "ultralytics": ultralytics.__version__,
        "torchvision": torchvision.__version__,
        "weights_loaded": False,
        "camera_opened": False,
    }
    logging.getLogger(__name__).info("Vision libraries prepared before window display in %.3fs", details["elapsed_s"])
    return details


def main(argv=None):
    parser = argparse.ArgumentParser(description="SENTINAL MARK-007 · local Vision Core")
    parser.add_argument("--config", help="Path to a JSON settings file")
    parser.add_argument("--device", choices=("auto", "cpu", "mps"), help="Preferred inference device; auto prefers working MPS")
    parser.add_argument("--video", help="Preselect a local video; monitoring still requires Start")
    args = parser.parse_args(argv)
    from PySide6.QtWidgets import QApplication, QMessageBox
    from sentinal.core.logger import configure_logging
    from sentinal.interface.main_window import MainWindow
    from sentinal.interface.themes import STYLESHEET

    app = QApplication(sys.argv[:1])
    app.setApplicationName("SENTINAL")
    app.setApplicationVersion("0.1.0")
    app.setOrganizationName("Project SENTINAL")
    app.setStyle("Fusion")
    app.setStyleSheet(STYLESHEET)
    configure_logging()
    try:
        config = load_config(args.config)
        if args.device:
            config = replace(config, device=args.device)
    except Exception as exc:
        logging.getLogger(__name__).exception("Could not load configuration")
        QMessageBox.critical(None, "SENTINAL · Settings error", f"Cannot load settings: {exc}\n\nCorrect the configuration file and reopen SENTINAL.")
        return 2
    try:
        prepare_runtime()
    except Exception:
        logging.getLogger(__name__).exception("Vision libraries could not initialize")
        QMessageBox.critical(None, "SENTINAL · Installation error", "Local vision libraries could not initialize. Run install.command, then reopen SENTINAL. Technical details are in logs/sentinal.log.")
        return 2
    window = MainWindow(config, args.video)
    window.show()
    signal.signal(signal.SIGINT, lambda *_: window.close())
    try:
        return app.exec()
    finally:
        # Also cover system/application Quit paths that bypass closeEvent.
        window.worker.request_shutdown()
        window.worker.wait()
