"""Camera discovery through device metadata; never opens a capture session."""
from dataclasses import dataclass
import logging

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class CameraInfo:
    index: int
    name: str
    device_id: str = ""
    is_default: bool = False


def discover_cameras():
    """List macOS cameras without activating them.

    OpenCV AVFoundation uses indices; Qt's metadata order is the best available
    passive mapping and may differ for unusual virtual camera drivers.
    """
    try:
        from PySide6.QtMultimedia import QMediaDevices
        default_id = bytes(QMediaDevices.defaultVideoInput().id())
        return [CameraInfo(i, camera.description(), bytes(camera.id()).hex(), bytes(camera.id()) == default_id)
                for i, camera in enumerate(QMediaDevices.videoInputs())]
    except Exception:
        log.exception("Passive camera enumeration failed")
        return []


class CameraManager:
    discover = staticmethod(discover_cameras)
