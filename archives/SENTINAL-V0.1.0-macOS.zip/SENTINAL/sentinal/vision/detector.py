"""Offline YOLO11 detector with supported Ultralytics ByteTrack integration."""
from dataclasses import replace
import logging
import os
from pathlib import Path
from threading import RLock
from time import perf_counter

from ..core.device_manager import select_device, synchronize
from .tracker import detections_from_result, reset_model_trackers
from .types import FOCUS_CLASSES

log = logging.getLogger(__name__)


class DetectorError(RuntimeError):
    pass


class YOLODetector:
    def __init__(self, config):
        self.config = config
        self.model = None
        self.device = "cpu"
        self.last_inference_ms = 0.0
        self.fallback_reason = None
        self._lock = RLock()
        self._track_offset = 0
        self._maximum_track_id = -1

    def load(self):
        with self._lock:
            if self.model is not None:
                return self
            weights = Path(self.config.weights)
            if not weights.is_file():
                raise DetectorError("Model weights are missing. Run install.command once to install models/yolo11n.pt.")
            try:
                # Missing dependencies must produce an error, not trigger pip online.
                os.environ.setdefault("YOLO_AUTOINSTALL", "false")
                import ultralytics
                from ultralytics import YOLO
                settings = getattr(ultralytics, "settings", None)
                if settings is not None and settings.get("sync", True):
                    settings.update({"sync": False})
                self.device = select_device(self.config.device)
                model = YOLO(str(weights), task="detect")
                names = set(model.names.values()) if isinstance(model.names, dict) else set(model.names)
                if not FOCUS_CLASSES.issubset(names):
                    raise DetectorError("The selected model does not support person, backpack, handbag and suitcase classes.")
                self.model = model
                log.info("Loaded local model %s; selected device %s", weights.name, self.device)
            except DetectorError:
                raise
            except Exception as exc:
                log.exception("Model loading failed")
                raise DetectorError("The local detection model could not load. Check installation and diagnostic logs.") from exc
        return self

    def reset_tracking(self):
        with self._lock:
            if self.model is not None:
                reset_model_trackers(self.model)
            self._track_offset = 0
            self._maximum_track_id = -1

    def _run(self, frame):
        # ByteTrack's second association stage needs low-confidence detections.
        # The user-facing threshold is applied only after tracking.
        return self.model.track(
            source=frame, persist=True, tracker="bytetrack.yaml", conf=0.05,
            iou=0.7, imgsz=self.config.image_size, device=self.device,
            verbose=False, save=False, stream=False,
        )[0]

    def infer(self, frame, confidence=None):
        import math
        import numpy as np
        if not isinstance(frame, np.ndarray) or frame.ndim != 3 or frame.shape[2] != 3 or not frame.size:
            raise ValueError("Inference requires a nonempty BGR image with three channels")
        threshold = self.config.confidence if confidence is None else float(confidence)
        if not math.isfinite(threshold) or not 0 <= threshold <= 1:
            raise ValueError("Confidence must be between zero and one")
        with self._lock:
            self.load()
            started = perf_counter()
            try:
                synchronize(self.device)
                result = self._run(frame)
                synchronize(self.device)
            except Exception as exc:
                if self.device != "mps":
                    log.exception("CPU inference failed")
                    raise DetectorError("Detection failed. Check the local model and diagnostic log.") from exc
                self.fallback_reason = f"MPS operation failed ({type(exc).__name__}); switched to CPU"
                log.warning(self.fallback_reason, exc_info=True)
                # Keep the same loaded weights. A predictor rebuild is needed
                # because its AutoBackend otherwise retains the old device.
                self.device = "cpu"
                self._track_offset = self._maximum_track_id + 1
                try:
                    self.model.to("cpu")
                    self.model.predictor = None
                    result = self._run(frame)
                except Exception as cpu_exc:
                    log.exception("CPU fallback inference failed")
                    raise DetectorError("Both MPS and CPU detection failed. See the diagnostic log.") from cpu_exc
            detections = detections_from_result(result, frame.shape, threshold)
            if self._track_offset:
                detections = tuple(replace(d, track_id=d.track_id + self._track_offset)
                                   if d.track_id is not None else d for d in detections)
            ids = [d.track_id for d in detections if d.track_id is not None]
            if ids:
                self._maximum_track_id = max(self._maximum_track_id, max(ids))
            self.last_inference_ms = (perf_counter() - started) * 1000
            return detections
