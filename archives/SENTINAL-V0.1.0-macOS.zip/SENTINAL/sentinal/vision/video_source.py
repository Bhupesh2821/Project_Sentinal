"""Exclusive camera capture and finite local-video decoding, independent of Qt."""
from dataclasses import dataclass
import logging
import math
from pathlib import Path
import sys
from threading import Lock
from time import monotonic

import cv2

log = logging.getLogger(__name__)
_camera_guard = Lock()
_active_cameras = set()


class VideoSourceError(RuntimeError):
    pass


@dataclass(frozen=True)
class SourceSpec:
    kind: str
    value: int | str

    def __post_init__(self):
        if self.kind not in {"camera", "file"}:
            raise ValueError("Source must be camera or file")
        if self.kind == "camera" and (type(self.value) is not int or self.value < 0):
            raise ValueError("Camera source requires a nonnegative integer index")
        if self.kind == "file" and (not isinstance(self.value, str) or not self.value.strip()):
            raise ValueError("File source requires a local path")


class VideoSource:
    def __init__(self, spec, width=640, height=480):
        self.spec = spec
        self.width, self.height = width, height
        self.state = "closed"
        self.capture = None
        self.fps = 0.0
        self.source_time_s = 0.0
        self.frame_index = 0
        self.frame_count = 0
        self._owns_camera = False
        self._started_at = 0.0

    @property
    def description(self):
        return f"Camera {self.spec.value}" if self.spec.kind == "camera" else Path(self.spec.value).name

    def open(self):
        if self.state == "open":
            return self
        self.close()
        self.frame_index, self.source_time_s = 0, 0.0
        try:
            if self.spec.kind == "file":
                path = Path(self.spec.value).expanduser()
                if not path.is_file():
                    raise VideoSourceError("The selected video file no longer exists.")
                self.capture = cv2.VideoCapture(str(path))
            else:
                with _camera_guard:
                    if self.spec.value in _active_cameras:
                        raise VideoSourceError("That camera is already open in SENTINAL. Stop the current session first.")
                    _active_cameras.add(self.spec.value)
                    self._owns_camera = True
                backend = cv2.CAP_AVFOUNDATION if sys.platform == "darwin" else cv2.CAP_ANY
                self.capture = cv2.VideoCapture(self.spec.value, backend)
            if not self.capture.isOpened():
                if self.spec.kind == "camera":
                    raise VideoSourceError("Camera unavailable. Connect a camera and allow camera access for the launcher in System Settings → Privacy & Security → Camera.")
                raise VideoSourceError("This video could not be opened. It may be corrupt or use an unsupported codec.")
            if self.spec.kind == "camera":
                self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
                self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
                self.capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # best effort; AVFoundation may ignore
            fps = float(self.capture.get(cv2.CAP_PROP_FPS))
            count = float(self.capture.get(cv2.CAP_PROP_FRAME_COUNT))
            self.fps = fps if math.isfinite(fps) and fps > 0 else 0.0
            self.frame_count = int(count) if math.isfinite(count) and count > 0 else 0
            self._started_at = monotonic()
            self.state = "open"
            return self
        except Exception as exc:
            self.close()
            self.state = "error"
            if isinstance(exc, VideoSourceError):
                raise
            log.exception("Failed to open video source")
            raise VideoSourceError("The video source could not be opened. See the diagnostic log.") from exc

    def read(self):
        if self.state == "eof":
            return None
        if self.state != "open" or self.capture is None:
            raise VideoSourceError("No video source is open. Start monitoring first.")
        try:
            ok, frame = self.capture.read()
            if not ok or frame is None or not frame.size:
                if self.spec.kind == "camera":
                    raise VideoSourceError("The camera stopped delivering frames. Check its connection and camera permission, then start again.")
                if self.frame_index == 0:
                    raise VideoSourceError("No frames could be decoded. The video may be empty, corrupt or use an unsupported codec.")
                if self.frame_count and self.frame_index < self.frame_count - 1:
                    raise VideoSourceError("The video ended before its advertised final frame. It may be damaged.")
                self.close()
                self.state = "eof"
                return None
            self.frame_index += 1
            if self.spec.kind == "camera":
                self.source_time_s = monotonic() - self._started_at
            else:
                millis = float(self.capture.get(cv2.CAP_PROP_POS_MSEC))
                self.source_time_s = millis / 1000 if math.isfinite(millis) and millis >= 0 else 0.0
                if not self.source_time_s and self.fps:
                    self.source_time_s = (self.frame_index - 1) / self.fps
            return frame
        except Exception as exc:
            self.close()
            self.state = "error"
            if isinstance(exc, VideoSourceError):
                raise
            log.exception("Video capture failed")
            raise VideoSourceError("The video source stopped unexpectedly. See the diagnostic log.") from exc

    def close(self):
        try:
            if self.capture is not None:
                self.capture.release()
        except Exception:
            log.exception("Capture backend reported an error while releasing resources")
        finally:
            self.capture = None
            if self._owns_camera:
                with _camera_guard:
                    _active_cameras.discard(self.spec.value)
                    self._owns_camera = False
            self.state = "closed"

    def restart(self):
        self.close()
        return self.open()

    def __enter__(self):
        return self.open()

    def __exit__(self, *_):
        self.close()
