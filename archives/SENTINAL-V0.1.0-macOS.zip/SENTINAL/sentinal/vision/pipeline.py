"""Single-source Vision Core. No Qt or persistence dependency."""
from time import perf_counter
from uuid import uuid4

from .detector import YOLODetector
from .performance import PerformanceMeter
from .types import FOCUS_CLASSES, FramePacket, utc_now
from .video_source import VideoSource, VideoSourceError


class VisionPipeline:
    def __init__(self, config):
        self.config = config
        self.detector = YOLODetector(config)
        self.performance = PerformanceMeter()
        self.source = None
        self.session_id = ""

    def start(self, spec):
        self.stop()
        self.detector.load()
        self.detector.reset_tracking()
        source = VideoSource(spec, self.config.camera_width, self.config.camera_height)
        source.open()
        self.source = source
        self.session_id = str(uuid4())
        self.performance.reset()
        return self.session_id

    def step(self, confidence=None, focus_only=False):
        if self.source is None:
            raise VideoSourceError("Start a monitoring session before requesting frames.")
        started = perf_counter()
        frame = self.source.read()
        if frame is None:
            return None
        detections = self.detector.infer(frame, confidence)
        if focus_only:
            detections = tuple(d for d in detections if d.label in FOCUS_CLASSES)
        self.performance.record(perf_counter() - started, self.detector.last_inference_ms)
        return FramePacket(
            frame=frame, detections=detections, session_id=self.session_id,
            source=self.source.description, frame_index=self.source.frame_index,
            timestamp=utc_now(), source_time_s=self.source.source_time_s,
            fps=self.performance.fps, inference_ms=self.detector.last_inference_ms,
            average_inference_ms=self.performance.average_inference_ms,
            device=self.detector.device,
        )

    def stop(self):
        if self.source is not None:
            self.source.close()
            self.source = None

    def reset(self):
        """Restart current source with a new session and fresh tracking identities."""
        if self.source is None:
            raise VideoSourceError("There is no source to restart.")
        return self.start(self.source.spec)
