"""A persistent vision thread and a one-frame mailbox for the Qt interface.

Qt signals carry state changes only. Video frames never accumulate in Qt's
event queue: the GUI takes the newest packet when its timer is ready.
"""
import logging
import queue
import threading
import time

from PySide6.QtCore import QThread, Signal

from sentinal.vision.pipeline import VisionPipeline
from sentinal.vision.video_source import VideoSourceError
from sentinal.vision.detector import DetectorError
from sentinal.core.event_manager import EventManager

log = logging.getLogger(__name__)


class InferenceWorker(QThread):
    state_changed = Signal(str, str)
    error = Signal(str)
    metadata_failed = Signal(str)

    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self._commands = queue.Queue()
        self._shutdown = threading.Event()
        self._stop_requested = threading.Event()
        self._lock = threading.Lock()
        self._latest = None
        self._confidence = config.confidence
        self._focus_only = False
        self._metadata_enabled = False
        self.pipeline = None

    def request_start(self, spec):
        self._commands.put(("start", spec))

    def request_stop(self):
        self._stop_requested.set()
        self._commands.put(("stop", None))

    def request_shutdown(self):
        self._shutdown.set()
        self._stop_requested.set()
        self._commands.put(("shutdown", None))

    def set_options(self, confidence=None, focus_only=None, metadata_enabled=None):
        with self._lock:
            if confidence is not None:
                self._confidence = confidence
            if focus_only is not None:
                self._focus_only = focus_only
            if metadata_enabled is not None:
                self._metadata_enabled = metadata_enabled

    def take_latest(self):
        with self._lock:
            packet, self._latest = self._latest, None
            return packet

    def run(self):
        active = False
        is_file = False
        events = None
        try:
            events = EventManager(self.config)
            while not self._shutdown.is_set():
                try:
                    command, argument = self._commands.get(timeout=0 if active else .1)
                except queue.Empty:
                    command, argument = None, None
                if command == "shutdown":
                    break
                if command == "stop":
                    if self.pipeline is not None:
                        self.pipeline.stop()
                    events.close()
                    active = False
                    with self._lock:
                        self._latest = None
                    self.state_changed.emit("stopped", "Monitoring stopped · source released")
                elif command == "start":
                    self._stop_requested.clear()
                    self.state_changed.emit("loading", "Opening source and loading local vision model…")
                    try:
                        events.close()
                        if self.pipeline is None:
                            self.pipeline = VisionPipeline(self.config)
                        self.pipeline.stop()
                        self.pipeline.start(argument)
                        is_file = argument.kind == "file"
                        active = True
                        self.state_changed.emit("running", "Monitoring · local inference active")
                    except Exception as exc:
                        active = False
                        if self.pipeline is not None:
                            self.pipeline.stop()
                        events.close()
                        self._report_failure(exc)
                if not active or self._stop_requested.is_set():
                    continue
                try:
                    frame_started = time.monotonic()
                    with self._lock:
                        confidence, focus, metadata = self._confidence, self._focus_only, self._metadata_enabled
                    packet = self.pipeline.step(confidence=confidence, focus_only=focus)
                    if packet is None:
                        self.pipeline.stop()
                        events.close()
                        active = False
                        self.state_changed.emit("eof", "Video complete · press Replay video to restart")
                        continue
                    if self._stop_requested.is_set() or self._shutdown.is_set():
                        continue
                    metadata_error = events.process(packet, enabled=metadata)
                    if metadata_error:
                        with self._lock:
                            self._metadata_enabled = False
                        events.close()
                        self.metadata_failed.emit(metadata_error)
                    with self._lock:
                        self._latest = packet
                    # Play files no faster than their declared source rate.
                    # Slower inference naturally slows playback; no frames are
                    # fabricated or silently skipped. Stop/quit interrupts waits.
                    if is_file:
                        source_fps = getattr(getattr(self.pipeline, "source", None), "fps", 0)
                        if source_fps > 0:
                            self._stop_requested.wait(max(0, 1 / source_fps - (time.monotonic() - frame_started)))
                except Exception as exc:
                    active = False
                    self.pipeline.stop()
                    events.close()
                    self._report_failure(exc)
        except Exception as exc:
            self._report_failure(exc)
        finally:
            if self.pipeline is not None:
                self.pipeline.stop()
            if events is not None:
                events.close()

    def _report_failure(self, error):
        log.exception("Vision worker failed")
        message = str(error).strip() if isinstance(error, (VideoSourceError, DetectorError)) else "Vision processing stopped unexpectedly. See the diagnostic log, then try starting again."
        self.state_changed.emit("error", "Monitoring unavailable · source released")
        self.error.emit(message)
