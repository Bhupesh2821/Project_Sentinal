"""SENTINAL desktop dashboard. Camera access requires an explicit Start action."""
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QSignalBlocker
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QFrame, QLabel, QPushButton, QComboBox, QCheckBox,
    QSlider, QFileDialog, QHBoxLayout, QVBoxLayout, QScrollArea,
)

from sentinal.vision.video_source import SourceSpec
from sentinal.vision.camera_manager import discover_cameras
from sentinal.vision.inference_worker import InferenceWorker
from sentinal.interface.video_panel import VideoPanel
from sentinal.interface.statistics_panel import StatisticsPanel


def label(text, name=None):
    widget = QLabel(text)
    if name:
        widget.setObjectName(name)
    return widget


class MainWindow(QMainWindow):
    def __init__(self, config, video_path=None):
        super().__init__()
        self.config = config
        self.video_path = None
        self._busy = False
        self._closing = False
        self._state = "idle"
        self.last_packet = None
        self.setWindowTitle("SENTINAL · MARK-007 · Vision Core")
        self.resize(1430, 900)
        self.setMinimumSize(1100, 740)
        self._build_interface()
        self.worker = InferenceWorker(config, self)
        self.worker.state_changed.connect(self._on_state)
        self.worker.error.connect(self._show_error)
        self.worker.metadata_failed.connect(self._metadata_error)
        self.worker.finished.connect(self._worker_finished)
        self.worker.start()
        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._poll_frame)
        self._timer.start()
        self.refresh_cameras()
        if video_path:
            self.load_video(video_path)

    def _build_interface(self):
        root = QWidget()
        self.setCentralWidget(root)
        page = QVBoxLayout(root)
        page.setContentsMargins(25, 17, 25, 18)
        page.setSpacing(17)
        header = QFrame()
        header.setObjectName("header")
        head = QHBoxLayout(header)
        head.setContentsMargins(0, 0, 0, 18)
        identity = QVBoxLayout()
        identity.setSpacing(4)
        identity.addWidget(label("SENTINAL", "brand"))
        identity.addWidget(label("MARK-007   /   VISION CORE   /   V0.1", "edition"))
        head.addLayout(identity)
        head.addStretch()
        head.addWidget(label("LOCAL VISION  ·  HUMAN OVERSIGHT", "edition"))
        head.addSpacing(22)
        self.status_chip = label("●  STANDBY", "statusChip")
        head.addWidget(self.status_chip)
        page.addWidget(header)

        body = QHBoxLayout()
        body.setSpacing(18)
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(276)
        side_shell = QVBoxLayout(sidebar)
        side_shell.setContentsMargins(1, 1, 1, 1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        sidebar_content = QWidget()
        sidebar_content.setObjectName("sidebarContents")
        scroll.setWidget(sidebar_content)
        side_shell.addWidget(scroll)
        side = QVBoxLayout(sidebar_content)
        side.setContentsMargins(18, 19, 18, 18)
        side.setSpacing(12)
        side.addWidget(label("MONITORING SOURCE", "sectionTitle"))
        self.source_type = QComboBox()
        self.source_type.addItems(["Camera", "Local video file"])
        self.source_type.currentIndexChanged.connect(self._source_type_changed)
        side.addWidget(self.source_type)
        camera_row = QHBoxLayout()
        camera_row.setSpacing(7)
        self.camera_combo = QComboBox()
        self.camera_combo.setMinimumWidth(0)
        self.camera_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.camera_combo.setMinimumContentsLength(12)
        camera_row.addWidget(self.camera_combo, 1)
        self.refresh_button = QPushButton("↻")
        self.refresh_button.setFixedWidth(36)
        self.refresh_button.setToolTip("Refresh device names without opening cameras")
        self.refresh_button.clicked.connect(self.refresh_cameras)
        camera_row.addWidget(self.refresh_button)
        side.addLayout(camera_row)
        self.camera_note = label("Device order maps to camera indices on a best-effort basis.", "muted")
        self.camera_note.setWordWrap(True)
        side.addWidget(self.camera_note)
        self.open_button = QPushButton("Open video file…")
        self.open_button.clicked.connect(self.choose_video)
        side.addWidget(self.open_button)
        self.file_label = label("No video selected", "muted")
        self.file_label.setWordWrap(True)
        side.addWidget(self.file_label)

        side.addSpacing(5)
        self.start_button = QPushButton("Start monitoring")
        self.start_button.setObjectName("primary")
        self.start_button.clicked.connect(self.start_monitoring)
        side.addWidget(self.start_button)
        self.stop_button = QPushButton("Stop monitoring")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_monitoring)
        side.addWidget(self.stop_button)
        side.addSpacing(10)
        side.addWidget(label("DETECTION", "sectionTitle"))
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["All supported objects", "People and bags only"])
        self.filter_combo.currentIndexChanged.connect(self._options_changed)
        side.addWidget(self.filter_combo)
        confidence_row = QHBoxLayout()
        confidence_row.addWidget(label("Confidence threshold"))
        confidence_row.addStretch()
        self.confidence_label = label(f"{self.config.confidence:.0%}", "sourceName")
        confidence_row.addWidget(self.confidence_label)
        side.addLayout(confidence_row)
        self.confidence_slider = QSlider(Qt.Orientation.Horizontal)
        self.confidence_slider.setRange(5, 95)
        self.confidence_slider.setValue(round(self.config.confidence * 100))
        self.confidence_slider.valueChanged.connect(self._options_changed)
        side.addWidget(self.confidence_slider)
        self.boxes_toggle = QCheckBox("Bounding boxes")
        self.labels_toggle = QCheckBox("Object labels + confidence")
        self.ids_toggle = QCheckBox("Tracking IDs")
        for toggle in (self.boxes_toggle, self.labels_toggle, self.ids_toggle):
            toggle.setChecked(True)
            toggle.toggled.connect(self._annotations_changed)
            side.addWidget(toggle)
        side.addSpacing(10)
        side.addWidget(label("LOCAL METADATA", "sectionTitle"))
        self.metadata_toggle = QCheckBox("Record detection metadata")
        self.metadata_toggle.setChecked(False)
        self.metadata_toggle.toggled.connect(self._options_changed)
        side.addWidget(self.metadata_toggle)
        retention = label(f"Off by default. Samples every {self.config.sample_interval_s:g}s; retained for {self.config.retention_days} days, with a {self.config.max_detection_rows:,} row cap. No video or audio is recorded.", "muted")
        retention.setWordWrap(True)
        side.addWidget(retention)
        side.addStretch()
        privacy = label("ON-DEVICE PROCESSING\nNo face recognition. No identity inference.\nDetections require human interpretation.", "muted")
        privacy.setWordWrap(True)
        side.addWidget(privacy)
        body.addWidget(sidebar)

        main = QVBoxLayout()
        main.setSpacing(12)
        source_row = QHBoxLayout()
        source_row.addWidget(label("VISION FEED", "sectionTitle"))
        source_row.addStretch()
        self.source_name = label("No source active", "muted")
        self.source_name.setMaximumWidth(700)
        source_row.addWidget(self.source_name)
        main.addLayout(source_row)
        self.error_banner = label("", "banner")
        self.error_banner.setWordWrap(True)
        self.error_banner.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.error_banner.hide()
        main.addWidget(self.error_banner)
        self.video_panel = VideoPanel()
        main.addWidget(self.video_panel, 1)
        feed_footer = QHBoxLayout()
        self.connection_label = label("Standby · camera inactive", "muted")
        self.frame_label = label("No frames processed", "muted")
        feed_footer.addWidget(self.connection_label)
        feed_footer.addStretch()
        feed_footer.addWidget(self.frame_label)
        main.addLayout(feed_footer)
        self.statistics = StatisticsPanel()
        main.addWidget(self.statistics)
        note = label("Tracks associate objects across frames. IDs can change after occlusion; they do not identify people.", "muted")
        note.setWordWrap(True)
        main.addWidget(note)
        body.addLayout(main, 1)
        page.addLayout(body, 1)

    def refresh_cameras(self):
        previous = self.camera_combo.currentData()
        self.camera_combo.clear()
        devices = discover_cameras()
        for device in devices:
            self.camera_combo.addItem(f"{device.name} · {device.index}", device.index)
        if not devices:
            self.camera_combo.addItem("Default camera · 0", 0)
            self.camera_combo.setToolTip("Camera access is unconfirmed. Start will attempt real camera index 0.")
            self.camera_note.setText("No camera was enumerated. Start will attempt index 0 and report access failures.")
        else:
            self.camera_note.setText("Camera index mapping is best effort. If needed, try another listed device.")
            if previous is None:
                builtin = next((i for i, device in enumerate(devices) if any(name in device.name.lower() for name in ("facetime", "built-in", "macbook"))), None)
                preferred = builtin if builtin is not None else next((i for i, device in enumerate(devices) if device.is_default), 0)
                self.camera_combo.setCurrentIndex(preferred)
        if previous is not None:
            found = self.camera_combo.findData(previous)
            if found >= 0:
                self.camera_combo.setCurrentIndex(found)

    def choose_video(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Open a local video", str(Path.home()), "Video files (*.mp4 *.mov *.m4v *.avi *.mkv *.webm);;All files (*)")
        if filename:
            self.load_video(filename)

    def load_video(self, filename):
        self.video_path = str(Path(filename).expanduser().resolve())
        self.file_label.setText(Path(self.video_path).name)
        self.file_label.setToolTip(self.video_path)
        self.source_type.setCurrentIndex(1)
        self._source_type_changed()

    def _source_type_changed(self, *_):
        is_camera = self.source_type.currentIndex() == 0
        self.camera_combo.setEnabled(is_camera and not self._busy)
        self.refresh_button.setEnabled(is_camera and not self._busy)
        self.start_button.setText("Start monitoring")

    def start_monitoring(self):
        if self._busy or self._closing:
            return
        if self.source_type.currentIndex() == 1:
            if not self.video_path:
                self._show_error("Choose a local video file before starting monitoring.")
                return
            spec = SourceSpec("file", self.video_path)
            self.source_name.setText(Path(self.video_path).name)
        else:
            spec = SourceSpec("camera", int(self.camera_combo.currentData() or 0))
            self.source_name.setText(self.camera_combo.currentText())
        self.error_banner.hide()
        self.last_packet = None
        self.video_panel.clear_frame("PREPARING VISION CORE")
        self.statistics.reset_live()
        self.frame_label.setText("No frames processed in this session")
        self._set_busy(True)
        self.status_chip.setText("●  STARTING")
        self.connection_label.setText("Opening source and preparing local inference…")
        self.worker.request_start(spec)

    def stop_monitoring(self):
        if self._busy:
            self.stop_button.setEnabled(False)
            self.connection_label.setText("Stopping safely · waiting for current frame…")
            self.status_chip.setText("●  STOPPING")
            self.worker.request_stop()

    def _set_busy(self, busy):
        self._busy = busy
        self.start_button.setEnabled(not busy)
        self.stop_button.setEnabled(busy)
        self.source_type.setEnabled(not busy)
        self.open_button.setEnabled(not busy)
        self.camera_combo.setEnabled(not busy and self.source_type.currentIndex() == 0)
        self.refresh_button.setEnabled(not busy and self.source_type.currentIndex() == 0)

    def _on_state(self, state, message):
        self._state = state
        self.connection_label.setText(message)
        chips = {"loading": "●  PREPARING", "running": "●  MONITORING", "stopped": "●  STOPPED", "eof": "●  COMPLETE", "error": "●  SOURCE ERROR"}
        self.status_chip.setText(chips.get(state, "●  STANDBY"))
        self.status_chip.setStyleSheet("color: #f5bbc2; border-color: #694050; background: #331c25;" if state == "error" else "")
        if state in ("stopped", "eof", "error"):
            # Consume the last frame before showing an idle state.
            self._poll_frame()
            self._set_busy(False)
            if state == "eof":
                self.start_button.setText("Replay video")
            if state in ("stopped", "error"):
                self.statistics.reset_live()
            if state == "error":
                self.video_panel.clear_frame("SOURCE UNAVAILABLE")

    def _show_error(self, message):
        self.error_banner.setText(message)
        self.error_banner.show()

    def _metadata_error(self, message):
        with QSignalBlocker(self.metadata_toggle):
            self.metadata_toggle.setChecked(False)
        self._show_error(f"Metadata recording was disabled: {message} Video monitoring can continue.")

    def _options_changed(self, *_):
        confidence = self.confidence_slider.value() / 100
        self.confidence_label.setText(f"{confidence:.0%}")
        if hasattr(self, "worker"):
            self.worker.set_options(confidence=confidence, focus_only=self.filter_combo.currentIndex() == 1, metadata_enabled=self.metadata_toggle.isChecked())

    def _annotations_changed(self, *_):
        if hasattr(self, "video_panel"):
            self.video_panel.set_annotations(self.boxes_toggle.isChecked(), self.labels_toggle.isChecked(), self.ids_toggle.isChecked())

    def _poll_frame(self):
        packet = self.worker.take_latest()
        if packet is None:
            return
        self.last_packet = packet
        self.video_panel.set_packet(packet)
        self.statistics.update_packet(packet)
        seconds = max(0, int(packet.source_time_s))
        self.frame_label.setText(f"Frame {packet.frame_index:,}   ·   {seconds // 60:02d}:{seconds % 60:02d}   ·   {packet.frame.shape[1]} × {packet.frame.shape[0]}")

    def closeEvent(self, event):
        if self.worker.isRunning():
            event.ignore()
            self._closing = True
            self._set_busy(True)
            self.stop_button.setEnabled(False)
            self.status_chip.setText("●  CLOSING")
            self.connection_label.setText("Releasing camera, model and metadata resources…")
            self.worker.request_shutdown()
        else:
            self._timer.stop()
            event.accept()

    def _worker_finished(self):
        if self._closing:
            self.close()
        else:
            self._set_busy(False)
            self._show_error("The vision worker stopped. Close and reopen SENTINAL to resume.")
