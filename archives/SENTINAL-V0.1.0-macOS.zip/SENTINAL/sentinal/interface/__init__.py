"""Native Qt monitoring interface."""
